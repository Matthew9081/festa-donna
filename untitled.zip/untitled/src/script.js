function openEnvelope(){

let envelope=document.querySelector(".envelope");
envelope.classList.toggle("open");

let music=document.getElementById("music");
music.play();

createFlowers();

document.querySelector(".final-message").classList.add("show-message");

}

function createFlowers(){

for(let i=0;i<20;i++){

let flower=document.createElement("div");
flower.innerHTML="🌼";

flower.style.position="fixed";
flower.style.left=Math.random()*100+"vw";
flower.style.top="-20px";
flower.style.fontSize="26px";
flower.style.animation="fall 5s linear";

document.body.appendChild(flower);

setTimeout(()=>{
flower.remove();
},5000);

}

}